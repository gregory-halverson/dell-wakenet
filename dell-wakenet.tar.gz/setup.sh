cp ./wakenet.sh /etc/pm/sleep.d/wakenet.sh
chmod +x /etc/pm/sleep.d/wakenet.sh
