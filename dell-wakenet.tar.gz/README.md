# dell-wakenet
Fixes issue with Ubuntu disabling wifi after resuming from suspend
